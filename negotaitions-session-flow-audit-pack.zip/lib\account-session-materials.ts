import { ParticipantType } from "@/app/generated/prisma/client";
import type { AuthUser } from "@/lib/auth";
import {
  canAccessSession,
  getCurrentUserSessionAccess,
} from "@/lib/access-control";
import { secondsToDisplayMinutes } from "@/lib/negotiation-duration";
import { prisma } from "@/lib/prisma";
import { buildSessionCloseState } from "@/lib/session-close-state";
import { resolveSessionDisplayStatus } from "@/lib/session-display-status";
import type { SessionDisplayStatus } from "@/lib/session-display-status";
import { sessionRoleBriefingSelect } from "@/lib/session-role";
import {
  scopeAssignedParticipantsForParticipant,
  scopeAssignedParticipantsForObserver,
  scopeAssignedParticipantsForFacilitator,
} from "@/lib/privacy/serializers";

export type AccountMaterialsRole = {
  name: string;
  privateInstructions: string;
  objectives: string;
  constraints: string;
  hiddenInfo: string;
  fallbackPosition: string;
};

export type AccountMaterialsData = {
  /** Public DB id — not a secret token. Safe to embed in client HTML. */
  participantId: string;
  sessionId: string;
  participantType: "FACILITATOR" | "PARTICIPANT" | "OBSERVER";
  displayName: string;
  notes: string;
  /**
   * Phase 6.11B: Whether this PARTICIPANT has an assigned role.
   * False when participant joined without a role (waiting for facilitator assignment).
   * Always true for FACILITATOR and OBSERVER types.
   */
  hasAssignedRole: boolean;
  /** Only set for PARTICIPANT type with an assigned role; null otherwise. */
  caseRole: AccountMaterialsRole | null;
  session: {
    id: string;
    title: string;
    visibility: "PUBLIC" | "PRIVATE";
    caseTitle: string;
    roomLabel: string | null;
    preparationDurationMinutes: number;
    negotiationDurationMinutes: number;
    displayStatus: SessionDisplayStatus;
    negotiationState: string;
    isDeleted: boolean;
    closedByEvent: boolean;
    closedBeforeNegotiation: boolean;
    closedByEventAt: string | null;
    businessContext: string;
    publicInstructions: string;
    caseLanguage: string;
  };
  event: { id: string; title: string; lobbyUrl: string } | null;
  assignedParticipants: Array<{
    id: string;
    displayName: string;
    role: AccountMaterialsRole;
  }>;
  recording: {
    status: string;
    fileUrl: string | null;
    updatedAt: string;
    errorMessage: string | null;
  } | null;
  transcript: {
    text: string | null;
    diarizedText: string | null;
    updatedAt: string;
  } | null;
  /** Tokenless room URL — /room/[sessionId] without query params. */
  roomUrl: string;
  /** "locked" means participant has no assigned role yet — notes input is hidden. */
  notesVariant: "preparation" | "observer" | "facilitator" | "locked";
};

/**
 * Loads all session materials data for an authenticated account user.
 *
 * Access is checked by userId relation only — no joinToken is read, stored,
 * or returned. This keeps joinToken out of browser URL, HTML, and logs.
 *
 * Legacy /join/[joinToken] links now require login and redirect to this
 * account-authorized route after server-side binding.
 */
export async function getAccountMaterialsData(
  sessionId: string,
  user: AuthUser,
): Promise<AccountMaterialsData | null> {
  const access = await getCurrentUserSessionAccess(sessionId, user, {});
  if (!access || !canAccessSession(access)) {
    return null;
  }

  const userParticipantId = access.userParticipant?.id ?? null;

  const sessionData = await prisma.session.findUnique({
    where: { id: sessionId },
    select: {
      id: true,
      title: true,
      visibility: true,
      status: true,
      snapshotCaseTitle: true,
      roomLabel: true,
      snapshotBusinessContext: true,
      snapshotPublicInstructions: true,
      snapshotCaseLanguage: true,
      preparationDurationSeconds: true,
      durationSeconds: true,
      deletedAt: true,
      negotiationState: true,
      negotiationStartedAt: true,
      closedByEventAt: true,
      closeReason: true,
      event: {
        select: {
          id: true,
          title: true,
          status: true,
        },
      },
      participants: {
        select: {
          id: true,
          displayName: true,
          type: true,
          notes: true,
          joinedAt: true,
          lastSeenAt: true,
          sessionRoleId: true,
          sessionRole: {
            select: sessionRoleBriefingSelect,
          },
        },
        orderBy: { createdAt: "asc" },
      },
      recording: {
        select: {
          status: true,
          fileUrl: true,
          updatedAt: true,
          errorMessage: true,
        },
      },
      transcript: {
        select: {
          text: true,
          diarizedText: true,
          updatedAt: true,
        },
      },
    },
  });

  if (!sessionData) return null;

  const closeState = buildSessionCloseState(sessionData);
  const displayStatus = resolveSessionDisplayStatus(
    sessionData,
    sessionData.participants,
  );

  // Resolve viewing participant: own participant > admin/host fall-through to facilitator.
  const participant = userParticipantId
    ? (sessionData.participants.find((p) => p.id === userParticipantId) ?? null)
    : null;

  const viewerParticipant =
    participant ??
    (access.isAdmin || access.isEventHostOwner
      ? (sessionData.participants.find((p) => p.type === "FACILITATOR") ??
          sessionData.participants[0] ??
          null)
      : null);

  if (!viewerParticipant) return null;

  const isParticipantType =
    viewerParticipant.type === ParticipantType.PARTICIPANT;
  const isObserverType = viewerParticipant.type === ParticipantType.OBSERVER;
  // Phase 6.11B: unassigned PARTICIPANT must not see private role materials or write notes.
  const hasAssignedRole = !isParticipantType || viewerParticipant.sessionRole !== null;

  // Phase 5: scope assigned participants by viewer type.
  // PARTICIPANT: own private briefing only; others get public role name only.
  // OBSERVER: role names only; no private fields.
  // FACILITATOR/ADMIN/HOST: all participant briefings.
  const allParticipantsForScoping = sessionData.participants.map((p) => ({
    id: p.id,
    displayName: p.displayName,
    type: p.type as string,
    sessionRole: p.sessionRole ?? null,
  }));
  const isFacilitatorOrAdmin =
    viewerParticipant.type === ParticipantType.FACILITATOR ||
    access.isAdmin ||
    access.isEventHostOwner;

  const assignedParticipants = isFacilitatorOrAdmin
    ? scopeAssignedParticipantsForFacilitator(allParticipantsForScoping)
    : isParticipantType
      ? scopeAssignedParticipantsForParticipant(allParticipantsForScoping, viewerParticipant.id)
      : scopeAssignedParticipantsForObserver(allParticipantsForScoping);

  return {
    participantId: viewerParticipant.id,
    sessionId: sessionData.id,
    participantType: viewerParticipant.type as "FACILITATOR" | "PARTICIPANT" | "OBSERVER",
    displayName: viewerParticipant.displayName,
    notes: viewerParticipant.notes,
    hasAssignedRole,
    // Phase 6.11B: only expose private role materials if role is assigned.
    caseRole: isParticipantType && hasAssignedRole ? (viewerParticipant.sessionRole ?? null) : null,
    session: {
      id: sessionData.id,
      title: sessionData.title,
      visibility: sessionData.visibility,
      caseTitle: sessionData.snapshotCaseTitle,
      roomLabel: sessionData.roomLabel,
      preparationDurationMinutes: secondsToDisplayMinutes(
        sessionData.preparationDurationSeconds,
      ),
      negotiationDurationMinutes: secondsToDisplayMinutes(
        sessionData.durationSeconds,
      ),
      displayStatus,
      negotiationState: sessionData.negotiationState,
      isDeleted: sessionData.deletedAt != null,
      closedByEvent: closeState.isClosed,
      closedBeforeNegotiation: closeState.closedBeforeNegotiation,
      closedByEventAt: sessionData.closedByEventAt?.toISOString() ?? null,
      businessContext: sessionData.snapshotBusinessContext,
      publicInstructions: sessionData.snapshotPublicInstructions,
      caseLanguage: sessionData.snapshotCaseLanguage,
    },
    event: sessionData.event
      ? {
          id: sessionData.event.id,
          title: sessionData.event.title,
          lobbyUrl: `/events/${sessionData.event.id}/lobby`,
        }
      : null,
    assignedParticipants,
    recording: sessionData.recording
      ? {
          status: sessionData.recording.status,
          fileUrl: sessionData.recording.fileUrl,
          updatedAt: sessionData.recording.updatedAt.toISOString(),
          errorMessage: sessionData.recording.errorMessage,
        }
      : null,
    transcript: sessionData.transcript
      ? {
          text: sessionData.transcript.text,
          diarizedText: sessionData.transcript.diarizedText,
          updatedAt: sessionData.transcript.updatedAt.toISOString(),
        }
      : null,
    roomUrl: `/room/${sessionData.id}`,
    // Phase 6.11B: unassigned PARTICIPANT sees "locked" variant (no notes input).
    notesVariant: isParticipantType
      ? hasAssignedRole
        ? "preparation"
        : "locked"
      : isObserverType
        ? "observer"
        : "facilitator",
  };
}
